import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SignupfinalPage } from './signupfinal';

@NgModule({
  declarations: [
    SignupfinalPage,
  ],
  imports: [
    IonicPageModule.forChild(SignupfinalPage),
  ],
})
export class SignupfinalPageModule {}
