import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { AddaddressPage } from '../addaddress/addaddress';

/**
 * Generated class for the AddressbookPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-addressbook',
  templateUrl: 'addressbook.html',
})
export class AddressbookPage {
	  tabBarElement: any;
 addressbook
 = [{ name: "Manish Garg"},{ name: "Ram Kumar"},{ name: "Rakesh"},{ name: "Mohan"},{ name: "Amit Sharma"}];

  constructor(public navCtrl: NavController, public navParams: NavParams) {
	  	  	  	  	  	      this.tabBarElement = document.querySelector('.tabbar.show-tabbar');

  }

  ionViewDidLoad() {
    this.tabBarElement.style.display = 'none';
    console.log('ionViewDidLoad AddressbookPage');
  }
  
  clickaddadress()
  { 
	  this.navCtrl.push(AddaddressPage);
  }

  
}
