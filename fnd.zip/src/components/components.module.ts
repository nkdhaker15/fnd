import { NgModule } from '@angular/core';
import { ShrinkingSegmentHeader } from './shrinking-segment-header/shrinking-segment-header';
@NgModule({
	declarations: [ShrinkingSegmentHeader],
	imports: [],
	exports: [ShrinkingSegmentHeader]
})
export class ComponentsModule {}
