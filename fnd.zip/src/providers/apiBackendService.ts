import { Http, Headers, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the RestProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ApiBackendService {
  apiUrl = 'http://shopkiee.com/project/fandd/webapi/register';
  constructor(public http: Http) {
    console.log('Hello RestProvider Provider');
  }
    
  getUsers() {
      return new Promise(resolve => {
        this.http.get(this.apiUrl+'/users.php').subscribe(data => {
          resolve(data);
        }, err => {
          console.log(err);
        });
      });
  } 
 getSliders() {
	return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/slider', {}, requestOptions)
          .subscribe(res => {
		    let resdata: any = res;
            resolve(JSON.parse(resdata._body));
          }, (err: any) => {
            resolve(this._handleError(err, true));
          });
      });
  } 

 loginUser(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/loginUser', data, requestOptions)
          .subscribe(res => {
            resolve(this._extractData(res));
          }, (err) => {
            resolve(this._handleError(err, false));
          });
      });
    }
  updateUser(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/updateuserprofile', data, requestOptions)
          .subscribe(res => {
            resolve(this._extractData(res));
          }, (err) => {
            resolve(this._handleError(err, false));
          });
      });
 }

  forgotPassword(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/forgotpassword', data, requestOptions)
          .subscribe(res => {
            resolve(this._extractData(res));
          }, (err) => {
             resolve(this._handleError(err, false));
          });
      });
 }

changePassword(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/changepassword', data, requestOptions)
          .subscribe(res => {
            resolve(this._extractData(res));
          }, (err) => {
             resolve(this._handleError(err, false));
          });
      });
 }

 registerUserStep1(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl, data, requestOptions)
          .subscribe(res => {
            resolve(this._extractData(res));
          }, (err) => {
            resolve(this._handleError(err, false));
          });
      });
    }

    registerUserStep2(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/verifyotp', data, requestOptions)
          .subscribe(res => {
            resolve(this._extractData(res));
          }, (err) => {
            resolve(this._handleError(err, false));
          });
      });
    } 

  resendUserOtp(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/resendotp', data, requestOptions)
          .subscribe(res => {
            resolve(this._extractData(res));
          }, (err) => {
            resolve(this._handleError(err, false));
          });
      });
    }

  registerUserFinalStep(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/finalregis', data, requestOptions)
          .subscribe(res => {
            resolve(this._extractData(res));
          }, (err) => {
            resolve(this._handleError(err, false));
          });
      });
    }

  addUser(data) {
      return new Promise((resolve, reject) => {
        var headers = new Headers();
        headers.append("Accept", 'application/json');
        headers.append('Content-Type', 'application/json' );
        const requestOptions = new RequestOptions({ headers: headers });
        this.http.post(this.apiUrl+'/register-user.php', data, requestOptions)
          .subscribe(res => {
            resolve(res);
          }, (err) => {
            resolve(this._handleError(err, false));
          });
      });
    }
   _extractData(response: any) {
       if(response.status == 200) {
           return JSON.parse(response._body);
       }
   }
   _handleError(error, multiple) {
       if(multiple) {
           return []; 
       }else {
            return {};        
       }
     
   }
}
