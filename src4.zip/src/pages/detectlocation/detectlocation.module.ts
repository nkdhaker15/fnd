import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetectlocationPage } from './detectlocation';

@NgModule({
  declarations: [
    DetectlocationPage,
  ],
  imports: [
    IonicPageModule.forChild(DetectlocationPage),
  ],
})
export class DetectlocationPageModule {}
